<?php namespace App\models;
    use CodeIgniter\Model;

    class usuarios extends Model {
        public function obtenerusuario($data){
            $usuario = $this->db->tablet('t_usuario');
            $usuario->were($data);
            return $usuario->get()-getResultArray();
        }
    }
?>